<?php
for ($i = 0; $i <=9; print $i++){};