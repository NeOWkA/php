<?php
$i = 0;

while ($i <= 100) {
    if ($i % 3 === 0) {
        echo $i . "<br>";
    }
    $i++;
}