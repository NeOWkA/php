<?php
$title = "Главная страница - страница обо мне";
$h1 = "Информация обо мне";
$year = date ( 'Y' );
include "site.php";