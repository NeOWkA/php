<?php
$a = 1;
$b = 2;
echo("a = {$a}, b = {$b}<br>");
$a+=+$b-$b=$a;
echo("a = {$a}, b = {$b}");