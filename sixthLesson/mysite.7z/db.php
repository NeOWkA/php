<?php
$db = @mysqli_connect("localhost", "gb","123456", "geekbrains") or die("Ошибка " . mysqli_connect_error());