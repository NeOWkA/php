<a href="/index.php">Галерея</a>
<a href="/catalog.php">Каталог</a>
<a href="/feedback.php">Отзывы</a>