<?php
$a = rand(0,15);
switch ($a){
    case 0:
        echo "{$a} "; $a++;
    case 1:
        echo "{$a} "; $a++;
    case 2:
        echo "{$a} "; $a++;
    case 3:
        echo "{$a} "; $a++;
    case 4:
        echo "{$a} "; $a++;
    case 5:
        echo "{$a} "; $a++;
    case 6:
        echo "{$a} "; $a++;
    case 7:
        echo "{$a} "; $a++;
    case 8:
        echo "{$a} "; $a++;
    case 9:
        echo "{$a} "; $a++;
    case 10:
        echo "{$a} "; $a++;
    case 11:
        echo "{$a} "; $a++;
    case 12:
        echo "{$a} "; $a++;
    case 13:
        echo "{$a} "; $a++;
    case 14:
        echo "{$a} "; $a++;
    case 15:
        echo "{$a}";
}
