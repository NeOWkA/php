<?php

$hash = password_hash("123", PASSWORD_DEFAULT);

var_dump(password_verify("1232", $hash));
