<?
//Подключаемся к БД
require "db.php";

if ($_GET['action'] == 'add') {
    $id = (int)$_GET['id'];
    mysqli_query($db, "INSERT INTO `basket`(`good_id`, `session_id`) VALUES ({$id}, '{$session}')");
    //Очистка URL
    header("Location: /catalog.php");
}

//Читаем данные этой картинки из БД
$result = mysqli_query($db, "SELECT * FROM `goods`");
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <title>Каталог</title>
</head>
<body>
<div id="main">
    <?php include "menu.php";?>
    <div class="post_title"><h2>Каталог</h2></div>
    <a class="catalog">
        <? while ($row = mysqli_fetch_assoc($result)): ?>
        <a href='show_good.php?id=<?=$row["id"]?>'><?=$row["name"]?></a>
        <div><img src='gallery_img_new/small/<?=$row["image"]?>' width="300px" /><br>Цена: <?=$row["price"]?></div>
        <a href="?action=add&id=<?= $row["id"] ?>">
            <button>Купить</button>
        </a>

            <hr>
        <?endwhile;?>

    </div>
</div>
</body>
</html>
