<?php



?>
    <!doctype html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">

        <title>Отзывы</title>
    </head>
    <body>
    <div id="main">
        <?php include "menu.php";?>
        <div class="post_title"><h2>Отзывы</h2></div>
        <div class="catalog">
            <?
            //Выводим все картинки в цикле формируя ссылку на вторую страницу по id
            while ($row = mysqli_fetch_assoc($result)): ?>
            <a href='show_image.php?id=<?=$row["id"]?>'><img src='gallery_img/small/<?=$row["filename"]?>' /></a><?=$row["likes"]?>

            <?endwhile;?>

        </div>
    </div>
    </body>
    </html>
<?php
